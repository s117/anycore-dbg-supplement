# !/usr/bin/env python3.8
# coding=utf8
# the above tag defines encoding for this document and is for Python 2.x compatibility
import itertools
import os
from typing import List, TextIO, Dict, Deque
import re
import sys
from collections import defaultdict, deque
from enum import Enum, auto
from pprint import pprint
from typing import Optional, Tuple
import click
import pyparsing as pyp
import bisect


class FunctionEntry:
    pass


class CallFrame:
    def __init__(self, ret_addr, is_exception):
        # type: (int, bool) -> None
        self.ret_addr = ret_addr
        self.shared_by = deque()  # type: Deque[Tuple[int, int, str, str]]
        self.is_execption = is_exception

    def add_call_rec(self, symbol_call_target):
        # type: (Tuple[int, int, str, str]) -> CallFrame
        self.shared_by.append(symbol_call_target)
        return self


class Instruction:
    reg_objdump_asm_line_pattern = r"^\s*([0-9a-fA-F]{1,16}):\s*([0-9a-fA-F]{8})\s+(.+)$"
    reg_objdump_asm_op_name = r"^\s*(\S+).*$"

    def __init__(self, offset, insn, objdump_dism):
        # type: (int, int, str) -> None
        self.offset = offset
        self.insn = insn
        self.objdump_dism = objdump_dism.strip()

    @staticmethod
    def _parse_objdump_asm_line(line):
        # type: (str) -> Optional[Instruction]
        matches = re.finditer(Instruction.reg_objdump_asm_line_pattern, line, re.MULTILINE)

        for matchNum, match in enumerate(matches, start=1):
            return Instruction(
                int(match.group(1), 16),
                int(match.group(2), 16),
                match.group(3)
            )

        return None

    def get_dism_op(self):
        # type: () -> str
        # matches = re.finditer(Instruction.reg_objdump_asm_op_name, self.objdump_dism, re.MULTILINE)
        #
        # for matchNum, match in enumerate(matches, start=1):
        #     return match.group(1)
        #
        # raise ValueError("Cannot extract op name from objdump dism output: [%s]" % self.objdump_dism)
        return self.objdump_dism.strip().split(" ")[0]


class Label:
    reg_objdump_label_line_pattern = r"^\s*([0-9a-fA-F]{1,16})\s*<(\S+)>\s*:\s*$"

    def __init__(self, offset, name):
        # type: (int, str) -> None
        self.name = name
        self.offset = offset

    @staticmethod
    def _parse_objdump_label_line(line):
        # type: (str) -> Optional[Label]
        matches = re.finditer(Label.reg_objdump_label_line_pattern, line, re.MULTILINE)

        for matchNum, match in enumerate(matches, start=1):
            return Label(
                int(match.group(1), 16),
                match.group(2)
            )

        return None


class SymbolTable:
    def __init__(self):
        self.symtab = list()  # type: List[Tuple[int, int, str, str]]
        self.aux_bisect_idx_arr = list()  # type: List[int]

    def find_symbol_by_addr(self, addr):
        # type: (int) -> Optional[Tuple[int, int, str, str]]
        symtab_idx = bisect.bisect_right(self.aux_bisect_idx_arr, addr)
        symtab_idx = max(symtab_idx - 1, 0)
        sym_rng_low = self.symtab[symtab_idx][0]
        sym_rng_high = self.symtab[symtab_idx][1]

        if sym_rng_low <= addr <= sym_rng_high:
            return self.symtab[symtab_idx]
        else:
            return None

    def add_symbol(self, module_name, symbol_info):
        # type: (str, Dict[str, Tuple[int, int]]) -> None
        self.symtab.extend(
            map(
                lambda item: (item[1][0], item[1][1], module_name, item[0]),
                symbol_info.items()
            )
        )

        self.symtab = sorted(self.symtab, key=lambda t: t[0])
        self.aux_bisect_idx_arr = list(map(lambda i: i[0], self.symtab))

        self._check_symbol_overlapping()

    def add_symbol_from_dism_file(self, dism_file_path):
        with open(dism_file_path, "r") as dism_file:
            parser = ObjdumpDismOutputParser(dism_file)
            fn_sym_table = dict()  # type: Dict[str, Tuple[int, int]]

            for x in parser.foreach():
                if isinstance(x, Instruction):
                    # print(x.get_dism_op())
                    fn_sym_table[parser.get_current_label().name] = (
                        fn_sym_table[parser.get_current_label().name][0],
                        x.offset
                    )
                elif isinstance(x, Label):
                    fn_sym_table[x.name] = (x.offset, x.offset)

        module_name = os.path.splitext(
            os.path.basename(dism_file_path)
        )[0]
        self.add_symbol(module_name, fn_sym_table)

    def _check_symbol_overlapping(self):
        def is_overlapping(rng1, rng2):
            # type: (Tuple[int, int], Tuple[int, int]) -> bool
            return max(rng1[0], rng2[0]) <= min(rng1[1], rng2[1])

        for s in self.symtab:
            if s[0] > s[1]:
                raise ValueError("Symbol %s (%s) has a invalid value range %08X - %08X (range_low > range_high)" % (
                    s[3], s[2], s[0], s[1]
                ))
        for i in range(len(self.symtab)):
            for j in range(i + 1, len(self.symtab)):
                if is_overlapping(self.symtab[i][0:2], self.symtab[j][0:2]):
                    print(
                        "Warning: symbol %s (%s) and %s (%s) overlapping" % (
                            self.symtab[i][3], self.symtab[i][2],
                            self.symtab[j][3], self.symtab[j][2]
                        ), file=sys.stderr
                    )


class ObjdumpDismOutputParser:
    parse_seq = (
        Instruction._parse_objdump_asm_line,
        Label._parse_objdump_label_line
    )

    class StepStatus(Enum):
        ST_NEW_INSN = auto()
        ST_NEW_LABEL = auto()
        ST_EOF = auto()

    def __init__(self, dism_file):
        if isinstance(dism_file, str):
            self.fp = open(dism_file, "r")
        else:
            self.fp = dism_file

        self.curr_label = None
        self.curr_insn = None

    def __del__(self):
        self.fp.close()

    def get_current_label(self) -> Label:
        return self.curr_label

    def get_curr_insn(self) -> Instruction:
        return self.curr_insn

    def step(self):
        while curr_line_text := self.fp.readline():
            for pf in self.parse_seq:
                parse_result = pf(curr_line_text)
                if isinstance(parse_result, Instruction):
                    self.curr_insn = parse_result
                    return self.StepStatus.ST_NEW_INSN
                elif isinstance(parse_result, Label):
                    self.curr_label = parse_result
                    return self.StepStatus.ST_NEW_LABEL

        return self.StepStatus.ST_EOF

    def foreach(self):
        while self.StepStatus.ST_EOF != (step_st := self.step()):
            if step_st == self.StepStatus.ST_NEW_INSN:
                yield self.get_curr_insn()
            else:
                yield self.get_current_label()


class TraceEventInstRetired:
    def __init__(self, cycle: int, seq: int, pc: int, insn: int, dism: str):
        self.cycle = cycle
        self.seq = seq
        self.insn = Instruction(pc, insn, dism.strip())


class SimpleTraceStreamReader:
    regex_insn_rec = r"^Cycle\s+(\d+):\s+Seq\s+(\d+)\s+PC\s+(0x[\da-fA-F]+)\s+\((0x[\da-fA-F]+)\)\s+(.+)$"

    def __init__(self, trace_txt):
        self.trace_txt = trace_txt
        self.trace_event = [ev for ev in self.foreach()]
        self.curr_ev_idx = 0
        print("11")

    def next(self):
        pass

    def foreach(self):
        seq_last = 0
        regex = SimpleTraceStreamReader.regex_insn_rec
        test_str = self.trace_txt
        matches = re.finditer(regex, test_str, re.MULTILINE)

        for match in matches:
            cycle = int(match.group(1))
            seq = int(match.group(2))
            pc = int(match.group(3), 16)
            insn = int(match.group(4), 16)
            asm = match.group(5)
            if seq != seq_last + 1:
                raise ValueError("Fail to parse the instruction record with sequence number %d" % (seq_last + 1))
            seq_last = seq
            yield TraceEventInstRetired(cycle, seq, pc, insn, asm)


class CallStackTracer:
    RESET_VECTOR = 0x2000
    EXEC_VECTOR = 0x4064
    INSN_SIZE_BYTE = 4

    def __init__(self, trace_file_path, symbol_table):
        # type: (str, SymbolTable) -> None
        with open(trace_file_path, "r") as tf:
            self.trace_file = SimpleTraceStreamReader(tf.read())
        self.symtab = symbol_table

    def trace_to(self, cycle):
        # type: (int) -> Deque[CallFrame]
        call_stack = deque()  # type: Deque[CallFrame]
        curr_cycle = 0
        # treat the power on reset as a initial call frame
        call_stack.append(CallFrame(0, True).add_call_rec(
            self.symtab.find_symbol_by_addr(CallStackTracer.RESET_VECTOR)
        ))
        last_tr_event = None  # type: Optional[TraceEventInstRetired]
        pending_call_dest_resolution = False

        for tr_event in self.trace_file.foreach():
            if int(tr_event.cycle) > cycle:
                break
            symbol_current = self.symtab.find_symbol_by_addr(tr_event.insn.offset)
            if pending_call_dest_resolution:
                assert symbol_current
                call_stack[-1].add_call_rec(symbol_current)
                pending_call_dest_resolution = False

            if tr_event.insn.offset == CallStackTracer.EXEC_VECTOR and \
                    last_tr_event.insn.offset != tr_event.insn.offset - CallStackTracer.INSN_SIZE_BYTE:
                new_frame = CallFrame(last_tr_event.insn.offset + CallStackTracer.INSN_SIZE_BYTE, True).add_call_rec(
                    self.symtab.find_symbol_by_addr(tr_event.insn.offset)
                )
                call_stack.append(new_frame)
            if tr_event.insn.get_dism_op() == "jal" or tr_event.insn.get_dism_op() == "jalr":
                # call with return
                new_frame = CallFrame(tr_event.insn.offset + CallStackTracer.INSN_SIZE_BYTE, False)
                call_stack.append(new_frame)
                pending_call_dest_resolution = True
            elif tr_event.insn.get_dism_op() == "j" or tr_event.insn.get_dism_op() == "jr" and tr_event.insn.offset == \
                    symbol_current[1]:
                # call without return (only can be seen at the end of a code)
                pending_call_dest_resolution = True
            elif tr_event.insn.get_dism_op() == "ret":
                assert not call_stack[-1].is_execption
                call_stack.pop()
            elif tr_event.insn.get_dism_op() == "sret":
                while not call_stack[-1].is_execption:
                    call_stack.pop()
                assert call_stack[-1].is_execption
                call_stack.pop()
            last_tr_event = tr_event

        return call_stack


def main():
    def print_stack_trace(stack_trace):
        # type: (Deque[CallFrame]) -> None
        while len(stack_trace):
            top_of_stack = stack_trace.pop()
            while len(top_of_stack.shared_by):
                print("%08X - %08X, [%s] - <%s>" % top_of_stack.shared_by.pop())
            if top_of_stack.is_execption:
                print("--Exception--")

    symtab = SymbolTable()
    symtab.add_symbol_from_dism_file("./pk_c920.dism")
    symtab.add_symbol_from_dism_file("./hello.dism")
    trace_file = "./retired_trace.txt"
    trace_file = sys.argv[1]

    # for s in symtab.symtab:
    #     print("%08X - %08X, [%s] - <%s>" % s)

    tracer = CallStackTracer(trace_file, symtab)
    print_stack_trace(tracer.trace_to(129696))
    # while (query := input("Query (addr)? ")) != "q":
    #     try:
    #         query_addr = int(query, 10)
    #     except ValueError:
    #         print("Invalid input [%s]." % query)
    #     else:
    #         print_stack_trace(tracer.trace_to(query_addr))


# @click.command()
# @click.argument(
#     'dism_file', required=False, type=click.Path
# )
# @click.argument(
#     'trace_file', required=False, type=click.Path
# )
# def main(dism_file: TextIO, trace_file: TextIO):
def main_query():
    symtab = SymbolTable()
    symtab.add_symbol_from_dism_file("./pk_c920.dism")
    symtab.add_symbol_from_dism_file("./hello.dism")

    for s in symtab.symtab:
        print("%08X - %08X, [%s] - <%s>" % s)

    while (query := input("Query (addr)? ")) != "q":
        try:
            query_addr = int(query, 10)
        except ValueError:
            print("Invalid input [%s]." % query)
        else:
            s = symtab.find_symbol_by_addr(query_addr)
            if s:
                print("%08X - %08X, [%s] - <%s>" % s)
            else:
                print("None")

        # if rng_low == rng_high:
        #     print("%s: <%s> - %08X - %08X" % (module_name, sym, rng_low, rng_high), file=sys.stderr)
        # else:
        #     print("%s: <%s> - %08X - %08X" % (module_name, sym, rng_low, rng_high))
    # tr = SimpleTraceReader(trace_file.read())
    # for i in tr.foreach():
    #     print(i)


if __name__ == '__main__':
    main()
